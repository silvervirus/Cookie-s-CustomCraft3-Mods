Welcome To Trollnautica


Needed Mods
CustomCraft2SML
SMLHelperv2
Asset go into CustomCraft2SML folder
Working folder can replace Working 




Known Bugs 
i can make the burger but can't eat it (limit from the mod as of now just waiting on an update)
Same with the bread and milk (limit from the mod used to make this mod Wait for update)