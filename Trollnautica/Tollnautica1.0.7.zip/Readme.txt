Welcome To Trollnautica


Needed Mods
CustomCraft2SML
SMLHelperv2
Asset go into CustomCraft2SML folder
Working folder can replace Working 




Known Bugs 
i can make the burger but can't eat it (limit from the mod as of now just waiting on an update)
Same with the bread and milk (limit from the mod used to make this mod Wait for update)


Change log 

1.0.9 
Added Solder, and Board making you craft these items before crafting other items you need made some custom tab and moved items inside them. renamed some files so it doesn't overwrite other mod files made for CC2.(released )
1.1.0
Adding Cyclops engine , Cyclops hull , cyclops Bridge , Seamoth hull left , Seamoth hull right , Seamoth engine