Install instructions
Extract Assets To
CustomCraft2SML folderfolder
Extract .txt files to WorkingFiles folder