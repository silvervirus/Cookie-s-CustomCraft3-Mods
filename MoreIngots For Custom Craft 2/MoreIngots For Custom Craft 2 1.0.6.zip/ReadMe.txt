Install instructions
Extract Assets To
CustomCraft2SML folderfolder
Extract .txt files to WorkingFiles folder


1.6 added Alterra Coin and emergencysupplies using the Coins to buy it 
1.6a reworked Emergencysupplies to be more worth it 
1.6b renamed asset for batterypack now it should work
